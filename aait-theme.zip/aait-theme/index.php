<?php get_header(); ?>
<div class="home-page padding-page">
  <?php  /* ?>
  <!-- START MAIN SLIDER  -->
  <div class="main-slider owl-carousel owl-theme">
    <?php 
      if(have_rows('slider_items' , 'option')){ $i=1;
        while(have_rows('slider_items' , 'option')){
          the_row(); ?>
        <div class="item image-wrap">
          <img src="<?php echo get_sub_field('slider_item_image' , 'option')?>" alt="img">
        </div>
      <?php $i++;    }} ?>
    <div class="slider-text head">
      <div class="container cont--text">
        <h3 class="title"><?php echo get_field('slider_items_title' , 'option')?></h3>
        <div class="text"><?php echo get_field('slider_items_text' , 'option')?></div>
      </div>
    </div>
  </div>
  <!--  END  MAIN SLIDER  -->
  <?php */ ?>
  <!-- START ABOUT SECTION -->
  <section class="about">
    <div class="container">
      <div class="content">
        <div class="head">
          <h3><?php lang_in('من نحن' , 'About')?></h3>
          <div class="text"><?php echo get_field('about_text' , 'option');?></div>
          <a href="<?php the_permalink()?>" class="main-btn reversed"><?php lang_in('عرض المزيد'  , 'Show More')?></a>
        </div>
        <div class="image-wrap"><img src="<?php echo get_field('about_img' , 'option')?>" alt="img"></div>
      </div>
    </div>
  </section>
  <!--  END  ABOUT SECTION -->
</div>

<?php get_footer(); ?>